# 贵州大学数学与统计学院蓝色 Beamer 模板

主文件：final_beamer.tex。主题文件：beamerthemegzu.sty。
主色为交大蓝 RGB(0, 121, 186)，十六进制 #0079BA。
普通内容框、例子、定义、定理均使用蓝色系；保留贵州大学校徽及建筑图案。
fig/logo.eps 为蓝色校徽，fig/line-blue.png 为蓝色建筑背景。
建筑背景为原图的 AI 配色编辑版本，局部线条和文字细节可能与原图不同。

## 编译

安装含中文字体支持的 TeX 发行版（MiKTeX 或 TeX Live），在本目录执行：

    latexmk

.latexmkrc 已配置 XeLaTeX，PDF 和编译辅助文件统一输出至 out/。
不使用 latexmk 时，在本目录连续运行两次：

    xelatex -interaction=nonstopmode -halt-on-error -output-directory=out final_beamer.tex

最终 PDF：out/final_beamer.pdf。

## 修改

在 final_beamer.tex 中修改 title、subtitle、author、institute 和 date。
默认启用建筑背景（linebg）；可改用 logobg 显示校徽水印。
在 beamerthemegzu.sty 中修改 swjtu_blue 可调整主色。
fig 中的素材已包含在本文件夹内，可整体复制到其他位置使用。
当前电脑的 latexmk 缺少 Perl 运行环境；已使用 XeLaTeX 编译验证。可按上述 XeLaTeX 命令编译，无需 Perl。
