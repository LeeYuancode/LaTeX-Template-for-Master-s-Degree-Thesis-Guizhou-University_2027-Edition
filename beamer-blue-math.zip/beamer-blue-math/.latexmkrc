$pdf_mode = 5;
$out_dir = 'out';
@default_files = ('final_beamer.tex');
$xelatex = 'xelatex -interaction=nonstopmode -halt-on-error -synctex=1 %O %S';